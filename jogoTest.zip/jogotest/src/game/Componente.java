package game;

public interface Componente {

	boolean isRetorno();
}
