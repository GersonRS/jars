package main;

import rpg.Iteracao;
import rpg.Personagem;

public class Principal extends Personagem{

	public Principal(int x, int y, int width, int height, int numFrames,
			String img) {
		super(x, y, width, height, numFrames, img);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void mover(Iteracao arg0) {
		// TODO Auto-generated method stub
		
	}

	
}
