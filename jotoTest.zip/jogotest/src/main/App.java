package main;

import java.awt.Graphics2D;

import rpg.Game;

public class App extends Game {

	@Override
	protected void onLoad() {
		loadCenario("cidade");
		configLayerBase("cidade", "grama");
		configLayerBase("cidade", "areia");
		configLayerBase("cidade", "casas");
		configLayerBase("cidade", "troncos");
		configLayerBase("cidade", "muros");
		configLayerSuperficie("cidade", "telhado");
		configLayerSuperficie("cidade", "folhas");
		addElementoPrincipal(new Principal(196, 100, 23, 55, 6,
		"personagem"));
		currentCenario("cidade");

	}

	@Override
	protected void onUpdate(int currentTick) {
		// TODO Auto-generated method stub

	}

	@Override
	protected void onRender(Graphics2D g) {
		renderCenarioBase(g);
		renderElementos(g);
		renderCenarioSuperficie(g);
	}

	@Override
	protected void onRenderHud(Graphics2D g) {
		// TODO Auto-generated method stub

	}

	public static void main(String[] args) {
		new Thread(new App()).start();
	}
}
